<?php

$geralClass = "/instaprint/painel/modules";

// Configuração dos módulos

$userClass = $geralClass."/user";
$clientesClass = $geralClass."/clientes";
$servicesClass = $geralClass."/services";

/* User Module */
include_once $_SERVER['DOCUMENT_ROOT'].$userClass.'/entity/User.php';
include_once $_SERVER['DOCUMENT_ROOT'].$userClass.'/controller/UserController.php';
include_once $_SERVER['DOCUMENT_ROOT'].$userClass.'/controller/AdminController.php';
/* /User Module */

/* Clientes Module */
# Entity
include_once $_SERVER['DOCUMENT_ROOT'] . $clientesClass . '/entity/Clientes.php';
include_once $_SERVER['DOCUMENT_ROOT'] . $clientesClass . '/entity/Contato.php';
include_once $_SERVER['DOCUMENT_ROOT'] . $clientesClass . '/entity/Endereco.php';
# /Entity

# Controller
include_once $_SERVER['DOCUMENT_ROOT'] . $clientesClass . '/controller/ClientesController.php';
include_once $_SERVER['DOCUMENT_ROOT'] . $clientesClass . '/controller/ContatoController.php';
include_once $_SERVER['DOCUMENT_ROOT'] . $clientesClass . '/controller/EnderecoController.php';
# /Controller

include_once $_SERVER['DOCUMENT_ROOT'] . $clientesClass . '/util/SimpleImage.php';
/* /Clientes Module */
?>