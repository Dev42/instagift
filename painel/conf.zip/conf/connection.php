<?php

if ($_SERVER['SERVER_ADDR'] == "127.0.0.1"){
    $dataBase = "instaprint";
    $host = "localhost";
    $user = "root";
    $pass = "";
    
}else {
    $dataBase = "quup_painel";
    $host = "mysql.quup.com.br";
    $user = "quup";
    $pass = "mysqlquupdbpass";
}

$conn = mysql_connect($host, $user, $pass);

if (!$conn){
    die ("Erro ao estabelecer conexão com o banco de dados! " . mysql_errno() . ": " . mysql_error());
}

$db_selected = mysql_select_db($dataBase, $conn);

if (!$db_selected){
    die ("Erro ao selecionar banco de dados!");
}

?>