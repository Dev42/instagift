		<div id="loading_overlay">
			<div class="loading_message round_bottom">
				<img src="<?php echo $urlGeral; ?>/images/loading.gif" alt="loading" />
			</div>
		</div>
		
	</body>
</html>